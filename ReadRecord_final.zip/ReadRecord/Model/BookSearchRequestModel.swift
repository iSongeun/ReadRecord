//
//  BookSearchRequestModel.swift
//  ReadRecord
//
//  Created by 이송은 on 2022/12/16.
//

import Foundation

struct BookSearchRequestModel : Codable {
    let query : String
}
