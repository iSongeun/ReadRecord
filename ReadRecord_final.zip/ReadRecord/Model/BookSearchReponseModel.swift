//
//  BookSearchReponseModel.swift
//  ReadRecord
//
//  Created by 이송은 on 2022/12/16.
//

import Foundation

struct BookSearchReponseModel : Decodable {
    var items : [Book] = []
    
}

