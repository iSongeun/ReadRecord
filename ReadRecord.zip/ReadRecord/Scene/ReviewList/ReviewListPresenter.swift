//
//  ReviewListPresenter.swift
//  ReadRecord
//
//  Created by 이송은 on 2022/12/14.
//

import Foundation
import UIKit

protocol ReviewListProtocol{
    func setupNavigationBar()
    func setupViews()
    func presentToReviewWriteViewController()
    func reloadTableView()
}

final class ReviewListPresenter : NSObject {
    private let viewController : ReviewListProtocol
    
    init(viewController: ReviewListProtocol) {
        self.viewController = viewController
    }
    
    func viewDidLoad() {
        viewController.setupNavigationBar()
        viewController.setupViews()
    }
    
    func viewWillAppear(){
        //내용업데이트
        viewController.reloadTableView()
    }
    func didTapRightBarButtonItem(){
        viewController.presentToReviewWriteViewController()
    }

}

extension ReviewListPresenter : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        cell.textLabel?.text = "\(indexPath)"
        return cell
        
    }
}
