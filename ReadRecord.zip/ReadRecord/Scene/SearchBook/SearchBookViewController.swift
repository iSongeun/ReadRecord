//
//  SearchBookViewController.swift
//  ReadRecord
//
//  Created by 이송은 on 2022/12/14.
//

import UIKit

final class SearchBookViewController : UIViewController {
    private lazy var presenter = SearchBookpresenter(viewController: self)
    override func viewDidLoad() {
        super.viewDidLoad()
        
        presenter.viewDidLoad()
    }
}

extension SearchBookViewController : SearchBookProtocol{
    func setupViews(){
        view.backgroundColor = .systemBackground
        let searchController = UISearchController()
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.delegate = presenter
        navigationItem.searchController = searchController
    }
}
