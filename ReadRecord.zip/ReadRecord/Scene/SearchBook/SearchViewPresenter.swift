//
//  SearchViewPresenter.swift
//  ReadRecord
//
//  Created by 이송은 on 2022/12/14.
//

import Foundation
import UIKit

protocol SearchBookProtocol {
    
}

final class SearchBookpresenter {
    private let viewController : SearchBookProtocol
    
    init(viewController: SearchBookProtocol) {
        self.viewController = viewController
    }
    func viewDidLoad(){
        
    }
}

extension SearchBookpresenter : UISearchBarDelegate {
    
}
