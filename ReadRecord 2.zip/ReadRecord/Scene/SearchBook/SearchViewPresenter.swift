//
//  SearchViewPresenter.swift
//  ReadRecord
//
//  Created by 이송은 on 2022/12/14.
//



import Foundation
import UIKit

protocol SearchBookProtocol {
    func setupViews()
    func dismiss()
}

final class SearchBookpresenter : NSObject {
    private let viewController : SearchBookProtocol
    
    init(viewController: SearchBookProtocol) {
        self.viewController = viewController
    }
    func viewDidLoad(){
        viewController.setupViews()
    }
}

extension SearchBookpresenter : UISearchBarDelegate {
    
}
extension SearchBookpresenter : UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        viewController.dismiss()
//        var selectResults : [Book] = []
//        let selectedBook = selectResults[indexPath.row]
    }
}

extension SearchBookpresenter : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        3
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = UITableViewCell()
        cell.textLabel?.text = "\(indexPath)"
        
        return cell
    }
}
