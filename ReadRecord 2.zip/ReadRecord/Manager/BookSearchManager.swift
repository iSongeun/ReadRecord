//
//  BookSearchManager.swift
//  ReadRecord
//
//  Created by 이송은 on 2022/12/16.
//
//client id : RhYg0XwCSCCfvl5S5L0W
//client secret : 5P5uZX2J7z

import Foundation
import Alamofire

struct BookSearchManager{
    func request(from keyword : String){
        guard let url = URL(string: "https://openapi.naver.com/v1/search/book.json") else {return}
        
        let parameters = BookSearchRequestModel(query: keyword)
    }
}
